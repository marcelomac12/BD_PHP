<?php 
     $hostname="localhost"; 
     $username="root"; 
     $usersenha="aluno"; 
     $banco="Filme"; 
     $conexao = mysqli_connect($hostname, $username, $usersenha, $banco); 
?>
