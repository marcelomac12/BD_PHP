<html>
<head> <title> Insere Filme </title></head>
<meta charset="utf-8">
<body>
	<h3><p>Cadastro de Filme
	<form action="inserirfilme.php" method="POST">
		<p>Nome <br> <input type="text" name="Nome">
		<p>Direcao <br> <input type="text" name="Direcao">
		<p>Elenco <br> <input type="text" name="Elenco">
		<p>Genero <br> <input type="text" name="Genero">
		<p>Nacionalidade <br> <input type="text" name="Nacionalidade">
		<p>Ano <br> <input type="text" name="Ano">
		<p>Sinopse <br> <input type="text" name="Sinopse">
		<p>Horas <br> <input type="text" name="Horas">
		
		<br><br> <input type="submit" value="Enviar">
	</form>
</body>
</html>
